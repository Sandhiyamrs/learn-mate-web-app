'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Trophy, Medal, Star, TrendingUp } from 'lucide-react';

const leaderboardData = [
  { rank: 1, name: 'Alex Chen', xp: 4850, streak: 12, avatar: '👨‍💻' },
  { rank: 2, name: 'Sarah Kim', xp: 4620, streak: 9, avatar: '👩‍🎓' },
  { rank: 3, name: 'Marcus Johnson', xp: 4390, streak: 15, avatar: '🧑‍🔬' },
  { rank: 4, name: 'Emma Rodriguez', xp: 4120, streak: 7, avatar: '👩‍💼' },
  { rank: 5, name: 'James Wilson', xp: 3950, streak: 6, avatar: '🧑‍💻' },
  { rank: 6, name: 'Priya Patel', xp: 3780, streak: 11, avatar: '👩‍🏫' },
  { rank: 7, name: 'David Lee', xp: 3620, streak: 5, avatar: '🧑‍🎨' },
  { rank: 8, name: 'Lisa Zhang', xp: 3450, streak: 8, avatar: '👩‍⚕️' },
];

const topThree = leaderboardData.slice(0, 3);
const restOfPlayers = leaderboardData.slice(3);

export default function LeaderboardPage() {
  const [friendCode, setFriendCode] = useState('');

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 backdrop-blur-md bg-black/20 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            LearnMate
          </Link>
          <Link href="/topics" className="text-slate-400 hover:text-white transition-colors">
            ← Back to Quiz
          </Link>
        </div>
      </nav>

      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl font-bold text-white mb-2">Leaderboard</h1>
        <p className="text-slate-400">See who's on top</p>
      </div>

      {/* Top 3 Podium */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* 2nd Place */}
          <div className="relative group order-first md:order-1">
            <div className="absolute inset-0 bg-gradient-to-r from-slate-400/20 to-slate-300/20 rounded-xl blur-lg group-hover:blur-xl transition-all"></div>
            <div className="relative p-6 bg-gradient-to-br from-slate-600/30 to-slate-700/30 backdrop-blur-xl border border-white/20 rounded-xl text-center">
              <div className="text-5xl mb-2">{topThree[1].avatar}</div>
              <Medal className="w-6 h-6 text-slate-400 mx-auto mb-2" />
              <h3 className="text-xl font-bold text-white mb-1">{topThree[1].name}</h3>
              <p className="text-2xl font-bold text-slate-300 mb-2">{topThree[1].xp} XP</p>
              <div className="flex items-center justify-center gap-1 text-slate-400">
                <Star className="w-4 h-4 text-yellow-400" />
                <span className="text-sm">{topThree[1].streak} streak</span>
              </div>
            </div>
          </div>

          {/* 1st Place */}
          <div className="relative group md:scale-110 order-none md:order-2">
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/30 to-orange-500/30 rounded-xl blur-xl group-hover:blur-xl transition-all"></div>
            <div className="relative p-8 bg-gradient-to-br from-yellow-500/20 to-orange-500/20 backdrop-blur-xl border border-yellow-400/50 rounded-xl text-center">
              <Trophy className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <div className="text-6xl mb-2">{topThree[0].avatar}</div>
              <h3 className="text-2xl font-bold text-yellow-300 mb-1">{topThree[0].name}</h3>
              <p className="text-3xl font-bold text-yellow-200 mb-2">{topThree[0].xp} XP</p>
              <div className="flex items-center justify-center gap-1 text-yellow-300">
                <Star className="w-4 h-4 fill-yellow-400" />
                <span className="text-sm font-semibold">{topThree[0].streak} streak</span>
              </div>
            </div>
          </div>

          {/* 3rd Place */}
          <div className="relative group order-last md:order-3">
            <div className="absolute inset-0 bg-gradient-to-r from-orange-400/20 to-red-400/20 rounded-xl blur-xl group-hover:blur-xl transition-all"></div>
            <div className="relative p-6 bg-gradient-to-br from-orange-600/30 to-red-600/30 backdrop-blur-xl border border-white/20 rounded-xl text-center">
              <div className="text-5xl mb-2">{topThree[2].avatar}</div>
              <Medal className="w-6 h-6 text-orange-400 mx-auto mb-2" />
              <h3 className="text-xl font-bold text-white mb-1">{topThree[2].name}</h3>
              <p className="text-2xl font-bold text-orange-300 mb-2">{topThree[2].xp} XP</p>
              <div className="flex items-center justify-center gap-1 text-orange-400">
                <Star className="w-4 h-4 text-yellow-400" />
                <span className="text-sm">{topThree[2].streak} streak</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Full Leaderboard */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-xl blur-xl group-hover:blur-xl transition-all"></div>
          <div className="relative p-6 bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-xl border border-white/10 rounded-xl">
            <h2 className="text-2xl font-bold text-white mb-6">Rankings</h2>
            <div className="space-y-2">
              {restOfPlayers.map((player) => (
                <div
                  key={player.rank}
                  className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-all"
                >
                  <div className="text-2xl font-bold text-slate-500 w-8">{player.rank}</div>
                  <div className="text-2xl w-8">{player.avatar}</div>
                  <div className="flex-1">
                    <div className="font-semibold text-white">{player.name}</div>
                    <div className="text-sm text-slate-400 flex items-center gap-2">
                      <Star className="w-3 h-3 text-yellow-400" />
                      {player.streak} day streak
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-blue-400 flex items-center gap-1">
                      <TrendingUp className="w-4 h-4" />
                      {player.xp} XP
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Friend Code Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-xl blur-xl group-hover:blur-xl transition-all"></div>
          <div className="relative p-8 bg-gradient-to-br from-purple-900/50 to-pink-900/50 backdrop-blur-xl border border-white/10 rounded-xl text-center">
            <h3 className="text-2xl font-bold text-white mb-4">Join a Friend's Challenge</h3>
            <p className="text-slate-400 mb-6">Enter your friend's code to see their progress</p>
            <div className="flex gap-2 max-w-md mx-auto">
              <input
                type="text"
                placeholder="Enter friend code..."
                value={friendCode}
                onChange={(e) => setFriendCode(e.target.value)}
                className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-400/50 focus:ring-1 focus:ring-blue-400/50"
              />
              <button className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg font-semibold text-white hover:shadow-lg hover:shadow-pink-500/50 transition-all">
                Join
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
