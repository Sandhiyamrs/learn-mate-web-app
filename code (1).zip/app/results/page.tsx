'use client';

import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { RotateCcw, Trophy, Home } from 'lucide-react';

export default function ResultsPage() {
  const searchParams = useSearchParams();
  const score = parseInt(searchParams.get('score') || '0');
  const total = parseInt(searchParams.get('total') || '5');
  const percentage = Math.round((score / total) * 100);

  const getEmoji = () => {
    if (percentage === 100) return '🏆';
    if (percentage >= 80) return '⭐';
    if (percentage >= 60) return '👍';
    return '💪';
  };

  const getMessage = () => {
    if (percentage === 100) return 'Perfect Score!';
    if (percentage >= 80) return 'Excellent Work!';
    if (percentage >= 60) return 'Good Job!';
    return 'Keep Practicing!';
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center px-4">
      <div className="w-full max-w-2xl">
        {/* Card */}
        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
          
          <div className="relative p-12 bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-xl border border-white/10 rounded-2xl text-center">
            {/* Emoji */}
            <div className="text-8xl mb-6 animate-bounce">{getEmoji()}</div>

            {/* Message */}
            <h1 className="text-4xl font-bold text-white mb-2">{getMessage()}</h1>
            <p className="text-slate-400 mb-8">Quiz Completed</p>

            {/* Score */}
            <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-white/10 rounded-xl p-8 mb-8">
              <div className="text-6xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-2">
                {score}/{total}
              </div>
              <div className="text-slate-400 mb-4">Score</div>
              
              {/* Progress Ring */}
              <div className="relative h-4 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-500"
                  style={{ width: `${percentage}%` }}
                ></div>
              </div>
              <p className="text-white font-bold mt-4">{percentage}% Correct</p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="p-4 bg-white/5 border border-white/10 rounded-lg">
                <div className="text-2xl font-bold text-green-400">{score}</div>
                <p className="text-slate-400 text-sm">Correct</p>
              </div>
              <div className="p-4 bg-white/5 border border-white/10 rounded-lg">
                <div className="text-2xl font-bold text-red-400">{total - score}</div>
                <p className="text-slate-400 text-sm">Incorrect</p>
              </div>
            </div>

            {/* XP Earned */}
            <div className="mb-8 p-4 bg-blue-500/20 border border-blue-400/50 rounded-lg">
              <p className="text-blue-300 font-semibold">+{score * 10} XP Earned</p>
            </div>

            {/* Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Link href="/topics" className="py-3 bg-white/5 border border-white/10 rounded-lg font-medium text-white hover:bg-white/10 transition-all flex items-center justify-center gap-2">
                <RotateCcw className="w-5 h-5" />
                <span>Retry</span>
              </Link>
              <Link href="/topics" className="py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg font-medium text-white hover:shadow-lg hover:shadow-purple-500/50 transition-all flex items-center justify-center gap-2">
                <Trophy className="w-5 h-5" />
                <span>Topics</span>
              </Link>
              <Link href="/" className="py-3 bg-white/5 border border-white/10 rounded-lg font-medium text-white hover:bg-white/10 transition-all flex items-center justify-center gap-2">
                <Home className="w-5 h-5" />
                <span>Home</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
