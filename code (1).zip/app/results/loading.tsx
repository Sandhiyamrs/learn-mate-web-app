export default function ResultsLoading() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center px-4">
      <div className="w-full max-w-2xl">
        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-2xl blur-xl"></div>
          
          <div className="relative p-12 bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-xl border border-white/10 rounded-2xl text-center">
            {/* Emoji Skeleton */}
            <div className="text-8xl mb-6 animate-pulse">⏳</div>

            {/* Message Skeleton */}
            <div className="h-10 bg-white/10 rounded w-64 mx-auto mb-2 animate-pulse"></div>
            <div className="h-5 bg-white/5 rounded w-32 mx-auto mb-8 animate-pulse"></div>

            {/* Score Skeleton */}
            <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-white/10 rounded-xl p-8 mb-8">
              <div className="h-16 bg-white/10 rounded w-40 mx-auto mb-4 animate-pulse"></div>
              <div className="h-6 bg-white/5 rounded w-24 mx-auto mb-4 animate-pulse"></div>
              <div className="h-4 bg-white/10 rounded-full overflow-hidden animate-pulse"></div>
              <div className="h-6 bg-white/5 rounded w-32 mx-auto mt-4 animate-pulse"></div>
            </div>

            {/* Stats Skeleton */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="p-4 bg-white/5 border border-white/10 rounded-lg">
                <div className="h-8 bg-white/10 rounded w-12 mx-auto mb-2 animate-pulse"></div>
                <div className="h-4 bg-white/5 rounded w-16 mx-auto animate-pulse"></div>
              </div>
              <div className="p-4 bg-white/5 border border-white/10 rounded-lg">
                <div className="h-8 bg-white/10 rounded w-12 mx-auto mb-2 animate-pulse"></div>
                <div className="h-4 bg-white/5 rounded w-16 mx-auto animate-pulse"></div>
              </div>
            </div>

            {/* XP Skeleton */}
            <div className="mb-8 p-4 bg-blue-500/20 border border-blue-400/50 rounded-lg">
              <div className="h-6 bg-blue-400/30 rounded w-32 mx-auto animate-pulse"></div>
            </div>

            {/* Buttons Skeleton */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="h-12 bg-white/5 border border-white/10 rounded-lg animate-pulse"></div>
              <div className="h-12 bg-gradient-to-r from-blue-500/50 to-purple-600/50 rounded-lg animate-pulse"></div>
              <div className="h-12 bg-white/5 border border-white/10 rounded-lg animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
