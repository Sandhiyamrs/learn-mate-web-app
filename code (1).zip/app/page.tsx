import Link from 'next/link';

export const metadata = {
  title: 'LearnMate - Smart Quiz Learning Platform',
  description: 'Boost your learning with interactive quizzes, instant feedback, and adaptive difficulty.',
};

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 backdrop-blur-md bg-black/20 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            LearnMate
          </div>
          <div className="flex gap-4">
            <Link href="/login" className="px-4 py-2 text-white hover:text-blue-300 transition-colors">
              Login
            </Link>
            <Link href="/signup" className="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg hover:shadow-lg hover:shadow-purple-500/50 transition-all">
              Sign Up
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-5xl md:text-6xl font-bold text-white text-balance leading-tight">
              Boost Your Learning with <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">Smart Quizzes</span>
            </h1>
            <p className="text-xl text-slate-300 text-balance">
              Practice. Improve. Master. Interactive quizzes designed to accelerate your learning journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Link href="/signup" className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg font-semibold text-white hover:shadow-lg hover:shadow-purple-500/50 transition-all text-center">
                Start Quiz
              </Link>
              <Link href="#features" className="px-8 py-3 border border-purple-400/50 rounded-lg font-semibold text-white hover:bg-purple-500/10 transition-all text-center">
                Learn More
              </Link>
            </div>
          </div>
          <div className="relative h-96 md:h-full min-h-96">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl blur-3xl animate-pulse"></div>
            <div className="relative h-full bg-gradient-to-br from-blue-500/10 to-purple-500/10 backdrop-blur-xl border border-white/10 rounded-2xl flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl mb-4">📚</div>
                <p className="text-lg text-slate-300">Interactive Learning Experience</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-4xl font-bold text-white text-center mb-12">Why LearnMate?</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: '🎯', title: 'Topic Quizzes', desc: 'Master subjects with focused topic-based quizzes' },
            { icon: '⚡', title: 'Instant Feedback', desc: 'Get immediate feedback on every answer' },
            { icon: '🏆', title: 'Leaderboard', desc: 'Compete with friends and track progress' },
            { icon: '🎲', title: 'Adaptive Difficulty', desc: 'Questions scale with your skill level' },
            { icon: '📊', title: 'Performance Analytics', desc: 'Detailed insights into your learning' },
            { icon: '🎁', title: 'Earn Rewards', desc: 'Gain XP and unlock achievements' },
          ].map((feature, idx) => (
            <div
              key={idx}
              className="group p-6 bg-gradient-to-br from-blue-500/10 to-purple-500/10 backdrop-blur-md border border-white/10 rounded-xl hover:border-purple-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/20"
            >
              <div className="text-4xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-slate-400">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 mb-8">
        <div className="relative p-12 bg-gradient-to-r from-blue-600/20 via-purple-600/20 to-cyan-600/20 backdrop-blur-xl border border-white/20 rounded-2xl text-center">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-2xl blur-2xl"></div>
          <div className="relative">
            <h3 className="text-3xl font-bold text-white mb-4">Ready to transform your learning?</h3>
            <p className="text-slate-300 mb-6 max-w-2xl mx-auto">Join thousands of learners already using LearnMate to master new skills and achieve their goals.</p>
            <Link href="/signup" className="inline-block px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg font-semibold text-white hover:shadow-lg hover:shadow-purple-500/50 transition-all">
              Get Started Free
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
