'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Search, BookOpen, Zap, Code, Globe, BarChart3, Lightbulb, Moon, Sun } from 'lucide-react';

const topics = [
  { id: 1, name: 'Science', icon: '🔬', description: 'Physics, Chemistry, Biology', color: 'from-blue-500 to-cyan-500' },
  { id: 2, name: 'Mathematics', icon: '📐', description: 'Algebra, Geometry, Calculus', color: 'from-purple-500 to-pink-500' },
  { id: 3, name: 'Technology', icon: '💻', description: 'AI, Cloud, Cybersecurity', color: 'from-green-500 to-emerald-500' },
  { id: 4, name: 'General Knowledge', icon: '🌍', description: 'History, Geography, Culture', color: 'from-orange-500 to-red-500' },
  { id: 5, name: 'English', icon: '📚', description: 'Grammar, Literature, Vocabulary', color: 'from-indigo-500 to-blue-500' },
  { id: 6, name: 'Coding', icon: '⚙️', description: 'JavaScript, Python, Web Dev', color: 'from-rose-500 to-pink-500' },
];

export default function TopicsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isDark, setIsDark] = useState(true);

  const filteredTopics = topics.filter(topic =>
    topic.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    topic.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <main className={`min-h-screen ${isDark ? 'bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900' : 'bg-gradient-to-br from-slate-50 to-purple-50'}`}>
      {/* Navbar */}
      <nav className={`sticky top-0 z-40 backdrop-blur-md ${isDark ? 'bg-black/20 border-white/10' : 'bg-white/20 border-black/10'} border-b`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            LearnMate
          </Link>
          <button
            onClick={() => setIsDark(!isDark)}
            className={`p-2 rounded-lg ${isDark ? 'bg-white/10 text-yellow-400' : 'bg-black/10 text-slate-800'} hover:scale-110 transition-transform`}
          >
            {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className={`text-4xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>Quiz Topics</h1>
        <p className={isDark ? 'text-slate-400' : 'text-slate-600'}>Choose a topic to start learning</p>
      </div>

      {/* Search */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="relative">
          <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 ${isDark ? 'text-slate-500' : 'text-slate-400'}`} />
          <input
            type="text"
            placeholder="Search topics..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={`w-full pl-12 pr-4 py-3 rounded-lg border transition-all ${
              isDark
                ? 'bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-blue-400/50 focus:ring-blue-400/50'
                : 'bg-white border-slate-200 text-slate-900 placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400'
            } focus:outline-none focus:ring-1`}
          />
        </div>
      </div>

      {/* Topics Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTopics.map((topic) => (
            <Link key={topic.id} href={`/quiz/${topic.id}`}>
              <div className={`group cursor-pointer h-full p-6 rounded-xl border transition-all duration-300 ${
                isDark
                  ? 'bg-gradient-to-br from-slate-800/50 to-purple-900/50 border-white/10 hover:border-purple-400/50 hover:shadow-lg hover:shadow-purple-500/20'
                  : 'bg-white border-slate-200 hover:border-blue-400 hover:shadow-lg hover:shadow-blue-400/20'
              } backdrop-blur-md`}>
                {/* Glow Background */}
                <div className={`absolute inset-0 bg-gradient-to-r ${topic.color} opacity-0 group-hover:opacity-10 rounded-xl transition-opacity duration-300`}></div>
                
                {/* Content */}
                <div className="relative">
                  <div className="text-5xl mb-4 group-group-hover:scale-110 transition-transform">{topic.icon}</div>
                  <h3 className={`text-xl font-semibold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                    {topic.name}
                  </h3>
                  <p className={isDark ? 'text-slate-400 text-sm' : 'text-slate-600 text-sm'}>{topic.description}</p>
                  
                  {/* Start Button */}
                  <div className={`mt-4 inline-block px-4 py-2 bg-gradient-to-r ${topic.color} rounded-lg font-medium text-white text-sm opacity-0 group-hover:opacity-100 transition-opacity`}>
                    Start Quiz →
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {filteredTopics.length === 0 && (
          <div className="text-center py-12">
            <p className={isDark ? 'text-slate-400' : 'text-slate-600'}>No topics found. Try a different search.</p>
          </div>
        )}
      </div>
    </main>
  );
}
