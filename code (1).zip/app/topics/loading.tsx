export default function TopicsLoading() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Navbar skeleton */}
      <nav className="sticky top-0 z-40 backdrop-blur-md bg-black/20 border-white/10 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="w-32 h-8 bg-gradient-to-r from-blue-400 to-purple-400 rounded animate-pulse"></div>
          <div className="w-10 h-10 bg-white/10 rounded-lg animate-pulse"></div>
        </div>
      </nav>

      {/* Header skeleton */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="w-64 h-10 bg-white/10 rounded animate-pulse mb-4"></div>
        <div className="w-96 h-6 bg-white/10 rounded animate-pulse"></div>
      </div>

      {/* Search skeleton */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
        <div className="w-full h-12 bg-white/10 rounded-lg animate-pulse"></div>
      </div>

      {/* Topics grid skeleton */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-64 bg-gradient-to-br from-slate-800/50 to-purple-900/50 border border-white/10 rounded-xl animate-pulse"></div>
          ))}
        </div>
      </div>
    </main>
  );
}
