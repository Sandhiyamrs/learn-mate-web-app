'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Edit2, Settings, LogOut, TrendingUp, Zap, Target, Medal, BookOpen, Award } from 'lucide-react';

const userStats = {
  username: 'John Doe',
  avatar: '👨‍💻',
  level: 12,
  xp: 3450,
  nextLevelXP: 5000,
  streak: 8,
  totalQuizzes: 124,
  accuracy: 78,
  achievements: [
    { icon: '🎯', name: 'First Quiz', description: 'Completed your first quiz' },
    { icon: '🔥', name: '7-Day Streak', description: 'Maintained a 7-day streak' },
    { icon: '💯', name: 'Perfect Score', description: 'Achieved 100% on a quiz' },
    { icon: '🏆', name: 'Top 10', description: 'Reached top 10 on leaderboard' },
    { icon: '⭐', name: 'Quiz Master', description: 'Completed 100 quizzes' },
    { icon: '🚀', name: 'Speed Runner', description: 'Completed quiz in under 2 minutes' },
  ],
  topicPerformance: [
    { name: 'Science', score: 82, quizzes: 24 },
    { name: 'Math', score: 76, quizzes: 18 },
    { name: 'English', score: 85, quizzes: 20 },
    { name: 'Technology', score: 72, quizzes: 15 },
    { name: 'History', score: 79, quizzes: 23 },
    { name: 'Geography', score: 81, quizzes: 24 },
  ],
};

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false);
  const xpProgress = (userStats.xp / userStats.nextLevelXP) * 100;

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 backdrop-blur-md bg-black/20 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            LearnMate
          </Link>
          <div className="flex gap-4">
            <Link href="/topics" className="text-slate-400 hover:text-white transition-colors text-sm">
              Continue Learning
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <div className="relative group mb-8">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all"></div>
          <div className="relative p-8 bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-xl border border-white/10 rounded-2xl">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-8 justify-between">
              <div className="flex items-center gap-6">
                <div className="text-8xl">{userStats.avatar}</div>
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{userStats.username}</h1>
                  <div className="flex gap-4 text-sm">
                    <span className="px-3 py-1 bg-blue-500/20 border border-blue-400/50 rounded-full text-blue-300">
                      Level {userStats.level}
                    </span>
                    <span className="px-3 py-1 bg-purple-500/20 border border-purple-400/50 rounded-full text-purple-300">
                      {userStats.totalQuizzes} Quizzes
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="px-4 py-2 bg-blue-500/20 border border-blue-400/50 rounded-lg text-blue-300 hover:bg-blue-500/30 transition-all flex items-center gap-2"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit Profile
                </button>
                <button className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-slate-300 hover:bg-white/10 transition-all flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Settings
                </button>
              </div>
            </div>

            {/* XP Progress */}
            <div className="mt-8 pt-8 border-t border-white/10">
              <div className="flex justify-between text-sm text-slate-400 mb-2">
                <span>Experience to Level {userStats.level + 1}</span>
                <span>{userStats.xp} / {userStats.nextLevelXP} XP</span>
              </div>
              <div className="h-3 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-500"
                  style={{ width: `${xpProgress}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: TrendingUp, label: 'Total XP', value: userStats.xp.toLocaleString() },
            { icon: Zap, label: 'Streak', value: `${userStats.streak} days` },
            { icon: Target, label: 'Accuracy', value: `${userStats.accuracy}%` },
            { icon: Medal, label: 'Top Position', value: '#47' },
          ].map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div key={idx} className="p-6 bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-xl border border-white/10 rounded-xl">
                <Icon className="w-6 h-6 text-blue-400 mb-3" />
                <p className="text-slate-400 text-sm mb-1">{stat.label}</p>
                <p className="text-2xl font-bold text-white">{stat.value}</p>
              </div>
            );
          })}
        </div>

        {/* Topic Performance */}
        <div className="relative group mb-8">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20 rounded-xl blur-xl group-hover:blur-xl transition-all"></div>
          <div className="relative p-6 bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-xl border border-white/10 rounded-xl">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <BookOpen className="w-6 h-6" />
              Topic Performance
            </h2>
            <div className="space-y-4">
              {userStats.topicPerformance.map((topic, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-white font-medium">{topic.name}</span>
                    <span className="text-blue-400">{topic.score}%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all"
                      style={{ width: `${topic.score}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-slate-500">{topic.quizzes} quizzes completed</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-600/20 to-orange-600/20 rounded-xl blur-xl group-hover:blur-xl transition-all"></div>
          <div className="relative p-6 bg-gradient-to-br from-slate-800/50 to-purple-900/50 backdrop-blur-xl border border-white/10 rounded-xl">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <Award className="w-6 h-6" />
              Achievements
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {userStats.achievements.map((achievement, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-white/5 border border-white/10 rounded-lg hover:border-yellow-400/50 transition-all text-center"
                >
                  <div className="text-4xl mb-2">{achievement.icon}</div>
                  <p className="text-sm font-semibold text-white">{achievement.name}</p>
                  <p className="text-xs text-slate-400 mt-1">{achievement.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
